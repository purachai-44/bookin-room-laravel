@extends('layouts.app')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card mb-4">
            <div class="card-header">
                <h4 class="mb-0">กรองข้อมูลการเข้าห้อง</h4>
            </div>
            <div class="card-body">
                <form method="GET" action="{{ route('fingerprints.index') }}">
                    <div class="form-group">
                        <label for="date">เลือกวันที่:</label>
                        <input type="date" id="date" name="date" class="form-control" value="{{ request('date') }}">
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <button type="submit" class="btn btn-primary">กรอง</button>
                        @if(Auth::user()->role === 'admin')
                            <a href="{{ route('fingerprints.pdf', ['date' => request('date')]) }}" class="btn btn-success">พิมพ์ PDF</a>
                        @endif
                    </div>
                </form>            
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">รายชื่อที่เข้าห้อง</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ชื่อ</th>
                                <th>นามสกุล</th>
                                <th>วันและเวลาที่เข้า</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($fingerprints as $fingerprint)
                            <tr>
                                <td>{{ $fingerprint->first_name }}</td>
                                <td>{{ $fingerprint->last_name }}</td>
                                <td>{{ \Carbon\Carbon::parse($fingerprint->time_in)->locale('th')->translatedFormat('j F Y H:i น.') }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection


        {{-- <div class="card">
            <div class="card-header">รายชื่อที่ออกห้อง</div>
            <div class="card-body">

                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ชื่อ</th>
                                <th>นามสกุล</th>
                                <th>วันและเวลาที่ออก</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($outFingerprints as $outFingerprint)
                            <tr>
                                <td>{{ $outFingerprint->first_name }}</td>
                                <td>{{ $outFingerprint->last_name }}</td>
                                <td>{{ $outFingerprint->time_out }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div> --}}