<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Reservation; 
use App\Models\Room;
use Carbon\Carbon;

class RoomController extends Controller
{
    public function index()
    {
        $rooms = Room::all();
        return view('rooms.index', compact('rooms'));
    }

    public function create()
    {
        return view('rooms.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'room_name' => 'required',
            'capacity' => 'required|integer',
            'equipment' => 'nullable',
        ]);

        Room::create($data);
        return redirect()->route('rooms.index')->with('success', 'เพิ่มห้องเรียนสำเร็จ!');
    }

    public function edit(Room $room)
    {
        return view('rooms.edit', compact('room'));
    }

    public function update(Request $request, Room $room)
    {
        $data = $request->validate([
            'room_name' => 'required',
            'capacity' => 'required|integer',
            'equipment' => 'nullable',
        ]);

        $room->update($data);
        return redirect()->route('rooms.index')->with('success', 'แก้ไขสำเร็จ');
    }

    public function destroy(Room $room)
    {
        $room->delete();
        return redirect()->route('rooms.index')->with('success', 'ลบสำเร็จ');
    }

    public function show()
    {
        $currentDateTime = Carbon::now();  // เวลาปัจจุบัน
    
        // ดึงข้อมูลห้องทั้งหมด
        $rooms = Room::all();
        
        foreach ($rooms as $room) {
    
            // ตรวจสอบว่ามีการจองที่ตรงกับช่วงวันและเวลาในปัจจุบัน
            $currentReservation = Reservation::where('room_id', $room->room_id)
                ->where('status', 'approved')
                ->where(function ($query) use ($currentDateTime) {
                    $query->where(function ($q) use ($currentDateTime) {
                        $q->whereDate('start_date', '<=', $currentDateTime->toDateString())  // ตรวจสอบวันเริ่ม
                          ->whereDate('end_date', '>=', $currentDateTime->toDateString());  // ตรวจสอบวันสิ้นสุด
                    })->where(function ($q) use ($currentDateTime) {
                        $q->whereTime('start_time', '<=', $currentDateTime->toTimeString())  // เวลาเริ่มต้องน้อยกว่าหรือเท่ากับปัจจุบัน
                          ->whereTime('end_time', '>', $currentDateTime->toTimeString());  // เวลาสิ้นสุดต้องมากกว่าปัจจุบัน
                    });
                })
                ->first();
        
            // ตั้งค่า is_occupied ว่าห้องว่างหรือไม่ว่าง
            $room->is_occupied = $currentReservation !== null;
        }
    
        // ส่งข้อมูลไปยัง view
        return view('rooms.show', compact('rooms'));
    }
    


}
