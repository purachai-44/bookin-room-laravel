<?php

namespace App\Http\Controllers;


use App\Models\VerifyFingerprint;
use Illuminate\Http\Request;
use Carbon\Carbon;
use TCPDF;

class VerifyFingerprintController extends Controller 
{
    public function index(Request $request)
    {

        $fingerprints = VerifyFingerprint::select('first_name', 'last_name', 'time_in')->get();

        $query = VerifyFingerprint::query();


        if ($request->has('date')) {
            $date = \Carbon\Carbon::parse($request->input('date'))->startOfDay();
            $query->whereDate('time_in', $date);
        }
    
        $fingerprints = $query->get();

        return view('fingerprints.index', compact('fingerprints'));
    }

    public function v_pdf(Request $request)
    {
        // ตรวจสอบว่ามีการส่งค่า date หรือไม่
        $query = VerifyFingerprint::select('first_name', 'last_name', 'time_in');
    
        if ($request->has('date')) {
            $date = \Carbon\Carbon::parse($request->input('date'))->startOfDay();
            $query->whereDate('time_in', $date);
        }
    
        // ดึงข้อมูลที่ถูกกรองแล้ว
        $fingerprints = $query->get();
    
        // Create a new TCPDF instance
        $pdf = new TCPDF();
        $pdf->AddPage();
    
        // ตรวจสอบว่าได้เพิ่มฟอนต์ภาษาไทย (THSarabun) อย่างถูกต้องหรือไม่
        $pdf->SetFont('thsarabun', '', 12); // ใช้ฟอนต์ภาษาไทยที่ถูกติดตั้ง
    
        // Set content
        $html = '<h2>รายชื่อที่เข้าห้อง</h2>';
        $html .= '<table border="1" cellpadding="4">';
        $html .= '<thead>
                    <tr>
                        <th>ชื่อ</th>
                        <th>นามสกุล</th>
                        <th>วันและเวลาที่เข้า</th>
                    </tr>
                  </thead><tbody>';
    
        foreach ($fingerprints as $fingerprint) {
            $html .= '<tr>
                        <td>' . $fingerprint->first_name . '</td>
                        <td>' . $fingerprint->last_name . '</td>
                        <td>' . \Carbon\Carbon::parse($fingerprint->time_in)->locale('th')->translatedFormat('j F Y H:i น.') . '</td>
                      </tr>';
        }
    
        $html .= '</tbody></table>';
    
        // Write HTML to the PDF
        $pdf->writeHTML($html, true, false, true, false, '');
    
        // Output the PDF to browser
        $pdf->Output('fingerprint_report.pdf', 'I'); 
    }
    
    
}



