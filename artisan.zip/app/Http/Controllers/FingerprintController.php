<?php

namespace App\Http\Controllers;

use App\Models\Fingerprint;
use Illuminate\Http\Request;
 
class FingerprintController extends Controller
{
    public function store(Request $request)
    {
        // รับข้อมูลลายนิ้วมือ
        $fingerprintId = $request->input('id');

        // ตรวจสอบว่าลายนิ้วมือถูกบันทึกหรือยัง
        $fingerprint = Fingerprint::create([
            'fingerprint_id' => $fingerprintId
        ]);

        return response()->json(['success' => true, 'fingerprint' => $fingerprint]);

        
    }
}



