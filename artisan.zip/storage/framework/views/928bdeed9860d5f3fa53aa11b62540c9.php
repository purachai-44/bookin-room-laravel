

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card">
            <div class="card-header">อนุมัติการจอง</div>
            <div class="card-body">
                
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php elseif(session('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th class="text-nowrap">ผู้จอง</th>
                                <th class="text-noerap">การใช้</th>
                                <th class="text-nowrap">ห้อง</th>
                                <th class="text-center">สถานะ</th>
                                <th colspan="3" class="text-center">ผลการจอง</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-nowrap">
                                    <?php if($reservation->member): ?>
                                    <?php echo e($reservation->member->first_name); ?> <?php echo e($reservation->member->last_name); ?>

                                    <?php else: ?>
                                    ไม่ทราบชื่อ
                                    <?php endif; ?>
                                </td>
                                <td class="text-nowrap"><?php echo e($reservation->purpose); ?></td>
                                <td class="text-nowrap"><?php echo e($reservation->room->room_name); ?></td>
                                <td>
                                    <?php if($reservation->status == 'pending'): ?>
                                        <span class="badge rounded-pill bg-warning text-white">รออนุมัติ</span>
                                    <?php elseif($reservation->status == 'approved'): ?>
                                        <span class="badge rounded-pill bg-success text-white">อนุมัติ</span>
                                    <?php elseif($reservation->status == 'rejected'): ?>
                                        <span class="badge rounded-pill bg-danger text-white">ไม่อนุมัติ</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <form id="approval-form-<?php echo e($reservation->reservation_id); ?>" action="<?php echo e(route('approvals.approve', $reservation->reservation_id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="approval_status" value="approved">
                                        <button type="button" class="btn btn-success btn-sm" onclick="approveReservation(<?php echo e($reservation->reservation_id); ?>)">อนุมัติ</button>
                                    </form>
                                </td>
                                <td>
                                    <form id="rejected-form-<?php echo e($reservation->reservation_id); ?>" action="<?php echo e(route('approvals.reject', $reservation->reservation_id)); ?>" method="POST" style="display:inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="approval_status" value="rejected">
                                        <button type="button" class="btn btn-danger btn-sm" onclick="rejectReservation(<?php echo e($reservation->reservation_id); ?>)">ยกเลิก</button>
                                    </form>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('reservations.edit', $reservation->reservation_id)); ?>" class="btn btn-primary btn-sm">แก้ไข</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
function approveReservation(reservationId) {
    Swal.fire({
        title: 'คุณแน่ใจหรือไม่?',
        text: "คุณต้องการอนุมัติการจองนี้หรือไม่?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'ใช่, อนุมัติเลย!',
        cancelButtonText: 'ยกเลิก'
    }).then((result) => {
        if (result.isConfirmed) {
            // Call a function to save to the database
            document.getElementById(`approval-form-${reservationId}`).submit();  // Submit form to save data
        }
    });
}


    function rejectReservation(reservationId) {
        Swal.fire({
            title: 'คุณแน่ใจหรือไม่?',
            text: "คุณต้องการยกเลิกการจองนี้หรือไม่?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'ใช่, ยกเลิกเลย!',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: "ลบสำเร็จ",
                    text: "ลบการจองสำเร็จ",
                    icon: "success",
                    showConfirmButton: false,
                    timer: 1500
                }).then(() => {
                    document.getElementById(`rejected-form-${reservationId}`).submit();
                });
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myproject2\resources\views/approvals/index.blade.php ENDPATH**/ ?>