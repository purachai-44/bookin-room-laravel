

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">แก้ไขห้อง</div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('rooms.update', $room->room_id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <label for="room_name" class="form-label">ชื่อห้อง</label>
                        <input type="text" class="form-control" id="room_name" name="room_name" value="<?php echo e($room->room_name); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="capacity" class="form-label">ความจุ</label>
                        <input type="number" class="form-control" id="capacity" name="capacity" value="<?php echo e($room->capacity); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="equipment" class="form-label">อุปกรณ์ถายในห้อง</label>
                        <textarea class="form-control" id="equipment" name="equipment"><?php echo e($room->equipment); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">อัพเดท</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myproject2\resources\views/rooms/edit.blade.php ENDPATH**/ ?>