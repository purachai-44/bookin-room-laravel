

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card mb-4">
            <div class="card-header">
                <h4 class="mb-0">กรองข้อมูลการเข้าห้อง</h4>
            </div>
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('fingerprints.index')); ?>">
                    <div class="form-group">
                        <label for="date">เลือกวันที่:</label>
                        <input type="date" id="date" name="date" class="form-control" value="<?php echo e(request('date')); ?>">
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <button type="submit" class="btn btn-primary">กรอง</button>
                        <?php if(Auth::user()->role === 'admin'): ?>
                            <a href="<?php echo e(route('fingerprints.pdf', ['date' => request('date')])); ?>" class="btn btn-success">พิมพ์ PDF</a>
                        <?php endif; ?>
                    </div>
                </form>            
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">รายชื่อที่เข้าห้อง</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ชื่อ</th>
                                <th>นามสกุล</th>
                                <th>วันและเวลาที่เข้า</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $fingerprints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fingerprint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($fingerprint->first_name); ?></td>
                                <td><?php echo e($fingerprint->last_name); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($fingerprint->time_in)->locale('th')->translatedFormat('j F Y H:i น.')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


        
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myproject2\resources\views/fingerprints/index.blade.php ENDPATH**/ ?>