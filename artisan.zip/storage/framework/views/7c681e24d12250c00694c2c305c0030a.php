<!DOCTYPE html>
<html>
<head>
    <title>รายละเอียดการจอง</title>
    <style>
        body {
            font-family: 'thsarabun', sans-serif;
            width: 80mm; /* ขนาดกระดาษ Thermal Paper */
            margin: 0;
            padding: 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 4px;
            text-align: left;
        }
        h1, h2 {
            font-size: 14px;
        }
        .info {
            font-size: 12px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <h1>รายการการจอง</h1>
    <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="info">
        <p><strong>ชื่อผู้จอง :</strong> <?php echo e($reservation->member ? $reservation->member->first_name . ' ' . $reservation->member->last_name : 'ไม่ทราบชื่อ'); ?></p>
        <p><strong>วัตถุประสงค์ :</strong> <?php echo e($reservation->purpose); ?></p>
        <p><strong>ห้องที่ใช้ :</strong> <?php echo e($reservation->room->room_name); ?></p>
        <p><strong>เวลา :</strong> <?php echo e($reservation->start_time); ?> <strong>ถึง :</strong> <?php echo e($reservation->end_time); ?></p>
        <p><strong>วันที่ :</strong> <?php echo e($reservation->start_date); ?> <strong>ถึง :</strong> <?php echo e($reservation->end_date); ?></p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\myproject2\resources\views/reservations/pdf.blade.php ENDPATH**/ ?>