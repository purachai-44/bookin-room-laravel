

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h4 class="mb-0">รายชื่อสมาชิกทั้งหมด</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th class="text-nowrap">ชื่อ</th>
                            <th class="text-nowrap">นามสกุล</th>
                            <th class="text-nowrap">โทรศัพท์</th>
                            <th class="text-nowrap">สถานะ</th>
                            <th class="text-nowrap">การจัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-nowrap"><?php echo e($member->first_name); ?></td>
                                <td class="text-nowrap"><?php echo e($member->last_name); ?></td>
                                <td class="text-nowrap"><?php echo e($member->phone); ?></td>
                                <td class="text-nowrap"><?php echo e($member->role == 'admin' ? 'ผู้ดูแล' : 'สมาชิก'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('members.adminedit', $member->member_id)); ?>" class="btn btn-primary btn-sm">แก้ไข</a>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myproject2\resources\views/members/upadmin.blade.php ENDPATH**/ ?>