

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h4 class="mb-0">แก้ไขข้อมูลสมาชิก: <?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?></h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('members.updateAdmin', $member->member_id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="first_name">ชื่อ</label>
                    <input type="text" name="first_name" id="first_name" class="form-control" value="<?php echo e($member->first_name); ?>" required>
                </div>
                <div class="form-group">
                    <label for="last_name">นามสกุล</label>
                    <input type="text" name="last_name" id="last_name" class="form-control" value="<?php echo e($member->last_name); ?>" required>
                </div>
                <div class="form-group">
                    <label for="phone">โทรศัพท์</label>
                    <input type="text" name="phone" id="phone" class="form-control" value="<?php echo e($member->phone); ?>" required>
                </div>
                <div class="form-group">
                    <label for="role">สถานะ</label>
                    <select name="role" id="role" class="form-control" required>
                        <option value="student" <?php echo e($member->role == 'student' ? 'selected' : ''); ?>>สมาชิก</option>
                        <option value="admin" <?php echo e($member->role == 'admin' ? 'selected' : ''); ?>>ผู้ดูแล</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="password">รหัสผ่านใหม่ (กรณีต้องการเปลี่ยน)</label>
                    <input type="password" name="password" id="password" class="form-control" minlength="8">
                </div>
                <button type="submit" class="btn btn-primary">บันทึกข้อมูล</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myproject2\resources\views/members/adminedit.blade.php ENDPATH**/ ?>