@extends('layouts.app')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card">
            <div class="card-header">อนุมัติการจอง</div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ผู้จอง</th>
                            <th>การใช้</th>
                            <th>ห้อง</th>
                            <th>สถานะ</th>
                            <th colspan="3">ผลการจอง</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($reservations as $reservation)
                        <tr>
                            <td>
                                @if ($reservation->member)
                                {{ $reservation->member->first_name }} {{ $reservation->member->last_name }}
                                @else
                                ไม่ทราบชื่อ
                                @endif
                            </td>
                            <td>{{ $reservation->purpose }}</td>
                            <td>{{ $reservation->room->room_name }}</td>
                            <td>{{ $reservation->status }}</td>
                            <td>
                                <form id="approval-form-{{ $reservation->reservation_id }}"
                                    action="{{ route('approvals.approve', $reservation->reservation_id) }}"
                                    method="POST">
                                    @csrf
                                    <input type="hidden" name="approval_status" value="approved">
                                    <button type="button" class="btn btn-success btn-sm"
                                        onclick="approveReservation({{ $reservation->reservation_id }})">อนุมัติ</button>
                                </form>
                            </td>
                            <td>
                                <form id="rejected-form-{{ $reservation->reservation_id }}"
                                    action="{{ route('approvals.reject', $reservation->reservation_id) }}" method="POST"
                                    style="display:inline-block;">
                                    @csrf
                                    <input type="hidden" name="approval_status" value="rejected">
                                    <button type="button" class="btn btn-danger btn-sm"
                                        onclick="rejectReservation({{ $reservation->reservation_id }})">ยกเลิก</button>
                                </form>
                            </td>
                            <td>
                                <a href="{{ route('reservations.edit', $reservation->reservation_id) }}"
                                    class="btn btn-primary btn-sm">แก้ไข</a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <script>
                function approveReservation(reservationId) {
                    Swal.fire({
                        title: 'คุณแน่ใจหรือไม่?',
                        text: "คุณต้องการอนุมัติการจองนี้หรือไม่?",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'ใช่, อนุมัติเลย!',
                        cancelButtonText: 'ยกเลิก'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            Swal.fire({
                                title: "สำเร็จ!",
                                text: "อนุมัติแล้ว",
                                icon: "success",
                                showConfirmButton: false,
                                timer: 1500
                            }).then(() => {
                                document.getElementById(`approval-form-${reservationId}`).submit();
                            });
                        }
                    });
                }

                function rejectReservation(reservationId) {
                    Swal.fire({
                        title: 'คุณแน่ใจหรือไม่?',
                        text: "คุณต้องการยกเลิกการจองนี้หรือไม่?",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'ใช่, ยกเลิกเลย!',
                        cancelButtonText: 'ยกเลิก'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            Swal.fire({
                                title: "ลบสำเร็จ",
                                text: "ลบการจองสำเร็จ",
                                icon: "success",
                                showConfirmButton: false,
                                timer: 1500
                            }).then(() => {
                                document.getElementById(`rejected-form-${reservationId}`).submit();
                            });
                        }
                    });
                }
            </script>
@endsection