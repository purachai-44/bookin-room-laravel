

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card">
            <div class="card-header">การจัดการห้อง</div>
            <div class="card-body">
                <a href="<?php echo e(route('rooms.create')); ?>" class="btn btn-primary mb-3">เพิ่มห้อง</a>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ชื่อห้อง</th>
                            <th>ความจุ</th>
                            <th>อุปกรณ์ถายในห้อง</th>
                            <th colspan="2">การจัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($room->room_name); ?></td>
                            <td><?php echo e($room->capacity); ?></td>
                            <td><?php echo e($room->equipment); ?></td>
                            <td>
                                <a href="<?php echo e(route('rooms.edit', $room->room_id)); ?>" class="btn btn-warning btn-sm">แก้ไข</a>
                                <form action="<?php echo e(route('rooms.destroy', $room->room_id)); ?>" method="POST" style="display:inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </td>
                            <td>
                                <button type="submit" class="btn btn-danger btn-sm">ลบ</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myproject2\resources\views/rooms/index.blade.php ENDPATH**/ ?>