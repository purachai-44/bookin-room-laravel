<!DOCTYPE html>
<html>
<head>
    <title>รายการการจอง</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
    </style>
</head>
<body>
    <h1>รายการการจอง</h1>
    <table>
        <thead> 
            <tr>
                <th>ผู้จอง</th>
                <th>การใช้</th>
                <th>ห้อง</th>
                <th>สถานะ</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php if($reservation->member): ?>
                        <?php echo e($reservation->member->first_name); ?> <?php echo e($reservation->member->last_name); ?>

                    <?php else: ?>
                        ไม่ทราบชื่อ
                    <?php endif; ?>
                </td>
                <td><?php echo e($reservation->purpose); ?></td>
                <td><?php echo e($reservation->room->room_name); ?></td>
                <td><?php echo e($reservation->status); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\myproject2\resources\views/reservations/pdf.blade.php ENDPATH**/ ?>