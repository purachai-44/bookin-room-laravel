

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card">
            <div class="card-header">รายการจอง</div>
            <div class="card-body">
                <a href="<?php echo e(route('reservations.create')); ?>" class="btn btn-primary mb-3">จองห้อง</a>
                <form method="GET" action="<?php echo e(route('reservations.index')); ?>" class="mb-3">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="ค้นหาตามชื่อ" value="<?php echo e(request('search')); ?>">
                        <button type="submit" class="btn btn-secondary">ค้นหา</button>
                    </div>
                </form>

                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>วัตถุประสงค์</th>
                            <th>เวลา</th>
                            <th>ถึง</th>
                            <th>วันที่</th>
                            <th>ถึง</th>
                            <th>ห้อง</th>
                            <th>สถานะ</th>
                            <th colspan="3">แก้ไข</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($reservation->purpose); ?></td>
                            <td><?php echo e($reservation->start_time); ?></td>
                            <td><?php echo e($reservation->end_time); ?></td>
                            <td><?php echo e($reservation->start_date); ?></td>
                            <td><?php echo e($reservation->end_date); ?></td>
                            <td><?php echo e($reservation->room->room_name); ?></td>
                            <td><?php echo e($reservation->status); ?></td>
                            <td>
                                <a href="<?php echo e(route('reservations.edit', $reservation->reservation_id)); ?>" class="btn btn-warning btn-sm">แก้ไข</a>
                            </td>
                            <td>
                                <form id="rejected-form-<?php echo e($reservation->reservation_id); ?>" action="<?php echo e(route('reservations.destroy', $reservation->reservation_id)); ?>" method="POST" style="display:inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button" class="btn btn-danger btn-sm" onclick="rejectReservation(<?php echo e($reservation->reservation_id); ?>)">ยกเลิก</button>
                                </form>                                                               
                            </td>
                            <td>
                                <a href="<?php echo e(route('reservations.pdf')); ?>" class="btn btn-primary">PDF</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            
                <div class="d-flex justify-content-center">
                    <?php echo e($reservations->links()); ?>

                </div>
            </div>
            
            <script>
                function rejectReservation(reservationId) {
                    Swal.fire({
                        title: 'คุณแน่ใจหรือไม่?',
                        text: "คุณต้องการยกเลิกการจองนี้หรือไม่?",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'ใช่, ยกเลิกเลย!',
                        cancelButtonText: 'ยกเลิก'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            Swal.fire({
                                title: "ลบสำเร็จ",
                                text: "ลบการจองสำเร็จ",
                                icon: "success",
                                showConfirmButton: false,
                                timer: 1500
                            }).then(() => {
                                document.getElementById(`rejected-form-${reservationId}`).submit();
                            });
                        }
                    });
                }
            </script>
            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myproject2\resources\views/reservations/index.blade.php ENDPATH**/ ?>