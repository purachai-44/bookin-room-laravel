

<?php $__env->startSection('content'); ?>
    <style>
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            position: relative;
        }
        .room1, .room2, .room3, .room4, .room5, .room6, .hallway1, .hallway2, .hallway3 {
            background: #797979;
        }
        .room1 {
            width: 118px;
            height: 88px;
            position: absolute;
            left: 0;
            top: 0;
        }
        .room2 {
            width: 116px;
            height: 88px;
            position: absolute;
            left: 131px;
            top: 0;
        }
        .room3 {
            width: 107px;
            height: 88px;
            position: absolute;
            left: 259px;
            top: 0;
        }
        .hallway1 {
            width: 366px;
            height: 48px;
            position: absolute;
            left: 0;
            top: 101px;
        }
        .hallway2 {
            width: 216px;
            height: 48px;
            position: absolute;
            left: 151px;
            top: 175px;
        }
        .hallway3 {
            width: 59px;
            height: 440px;
            position: absolute;
            left: 140px;
            top: 140px;
        }
        .room4 {
            width: 150px;
            height: 102px;
            position: absolute;
            left: 216px;
            top: 248px;
        }
        .room5 {
            width: 150px;
            height: 102px;
            position: absolute;
            left: 216px;
            top: 363px;
        }
        .room6 {
            width: 150px;
            height: 102px;
            position: absolute;
            left: 217px;
            top: 478px;
        }
    </style>
    <div class="container">
        <div class="room1"></div>
        <div class="room2"></div>
        <div class="room3"></div>
        <div class="hallway1"></div>
        <div class="hallway2"></div>
        <div class="hallway3"></div>
        <div class="room4"></div>
        <div class="room5"></div>
        <div class="room6"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myproject2\resources\views/rooms/show.blade.php ENDPATH**/ ?>